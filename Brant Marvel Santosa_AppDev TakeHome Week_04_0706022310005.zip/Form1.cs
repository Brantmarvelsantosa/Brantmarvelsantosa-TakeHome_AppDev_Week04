﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brant_Marvel_Santosa___AppDev_TakeHome_Week_04___0706022310005
{
    public partial class Form1 : Form
    {
        DataTable Football = new DataTable();
        bool check1 = false;
        bool check2 = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Football.Columns.Add("Country");
            Football.Columns.Add("Team");
            Football.Columns.Add("Player Number");
            Football.Columns.Add("Player Name");
            Football.Columns.Add("Player Position");
            Football.Rows.Add("England", "Manchester City", "09", "Erling Haaland", "FW");
            Football.Rows.Add("England", "Manchester City", "47", "Phil Foden", "FW");
            Football.Rows.Add("England", "Manchester City", "16", "Rodri", "MF");
            Football.Rows.Add("England", "Manchester City", "19", "Julian Alvarez", "FW");
            Football.Rows.Add("England", "Manchester City", "20", "Bernardo Silva", "FW");
            Football.Rows.Add("England", "Manchester City", "03", "Ruben Dias", "DF");
            Football.Rows.Add("England", "Manchester City", "24", "Josko Gvardiol", "DF");
            Football.Rows.Add("England", "Manchester City", "10", "Jack Grealish", "FW");
            Football.Rows.Add("England", "Manchester City", "11", "Jeremy Doku", "FW");
            Football.Rows.Add("England", "Manchester City", "17", "Kevin De Bruyne", "FW");
            Football.Rows.Add("England", "Manchester City", "27", "Matheus Nunes", "FW");
            Football.Rows.Add("England", "Liverpool FC", "08", "Dominik Szoboszlai", "MF");
            Football.Rows.Add("England", "Liverpool FC", "07", "Luis Diaz", "FW");
            Football.Rows.Add("England", "Liverpool FC", "66", "Trent Alexander-Arnold", "DF");
            Football.Rows.Add("England", "Liverpool FC", "10", "Alexis Mac Allister", "MF");
            Football.Rows.Add("England", "Liverpool FC", "09", "Darwin Nunez", "FW");
            Football.Rows.Add("England", "Liverpool FC", "11", "Mohamed Salah", "FW");
            Football.Rows.Add("England", "Liverpool FC", "20", "Diogo Jota", "FW");
            Football.Rows.Add("England", "Liverpool FC", "18", "Cody Gakpo", "FW");
            Football.Rows.Add("England", "Liverpool FC", "05", "Ibrahima Konate", "DF");
            Football.Rows.Add("England", "Liverpool FC", "26", "Andrew Robertson", "DF");
            Football.Rows.Add("England", "Liverpool FC", "17", "Curtis Jones", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "10", "Lautaro Martinez", "FW");
            Football.Rows.Add("Italy", "Inter Milan", "23", "Nicolo Barella", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "95", "Alessandro Bastoni", "DF");
            Football.Rows.Add("Italy", "Inter Milan", "09", "Marcus Thuram", "FW");
            Football.Rows.Add("Italy", "Inter Milan", "32", "Federico Dimarco", "DF");
            Football.Rows.Add("Italy", "Inter Milan", "28", "Benjamin Pavard", "DF");
            Football.Rows.Add("Italy", "Inter Milan", "20", "Hakan Çalhanoğlu", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "16", "Davide Fratessi", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "02", "Denzel Dumfries", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "30", "Carlos Augusto", "MF");
            Football.Rows.Add("Italy", "Inter Milan", "21", "Kristjan Asllani", "MF");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void ComboBox_ChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox_ChooseTeam.Items.Clear();
            for (int i = 0; i < Football.Rows.Count; i++)
            {
                if (Football.Rows[i][0] == ComboBox_ChooseCountry.SelectedItem)
                {
                    if (!ComboBox_ChooseTeam.Items.Contains(Football.Rows[i][1]))
                    {
                        ComboBox_ChooseTeam.Items.Add(Football.Rows[i][1]);
                    }
                }
                else
                {
                    ComboBox_ChooseTeam.Text = null;
                }
            }
        }

        private void ComboBox_ChooseCountry_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Football.Rows.Count; i++)
            {
                if (!ComboBox_ChooseCountry.Items.Contains(Football.Rows[i][0]))
                {
                    ComboBox_ChooseCountry.Items.Add(Football.Rows[i][0]);
                }
            }
        }

        private void button_removelistbox_Click(object sender, EventArgs e)
        {
            if (Listbox_Player.Items.Count == 0)
            {
                MessageBox.Show("Listbox harus ada isinya", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (Listbox_Player.Items.Count <= 11)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Listbox_Player.Items.RemoveAt(Listbox_Player.SelectedIndex);
            }
        }

        private void ComboBox_ChooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            Listbox_Player.Items.Clear();
            for (int i = 0; i < Football.Rows.Count; i++)
            {
                if (Football.Rows[i][1] == ComboBox_ChooseTeam.SelectedItem)
                {
                    Listbox_Player.Items.Add($"({Football.Rows[i][2]}) {Football.Rows[i][3]}, {Football.Rows[i][4]} ");
                }
            }
        }

        private void button_addteam_Click(object sender, EventArgs e)
        {
            foreach (DataRow dt in Football.Rows)
            {
                if (dt["Team"].ToString() == TB_TeamName.Text)
                {
                    MessageBox.Show("Team Already Available", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    check2 = true;
                    break;
                }
            }
            if (check2 == false)
            {
                if (TB_TeamCountry.Text == "" || TB_TeamName.Text == "" || TB_TeamCity.Text == "")
                {
                    MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (TB_TeamCountry.Text != null || TB_TeamName.Text != null || TB_TeamCity.Text != null)
                {
                    Football.Rows.Add($"{TB_TeamCountry.Text}", $"{TB_TeamName.Text}");
                    ComboBox_ChooseCountry.Items.Add(TB_TeamCountry.Text);
                    ComboBox_ChooseTeam.Items.Add(TB_TeamName.Text);
  
                }
            }
            TB_TeamCity.Clear();
            TB_TeamCountry.Clear();
            TB_TeamName.Clear();
        }

        private void button_addplayer_Click(object sender, EventArgs e)
        {
            if (TB_PlayerName.Text == null || TB_PlayerNumber.Text == null || ComboBox_PlayerPosition.SelectedItem == null)
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                foreach (DataRow dt in Football.Rows)
                {
                    if (dt["Team"].ToString() == ComboBox_ChooseTeam.SelectedItem && dt["Player Name"].ToString() == TB_PlayerName.Text)
                    {
                        MessageBox.Show("There are Players with the same Player Name", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        check1 = true;
                    }
                }

                if (check1 == false)
                {
                    Football.Rows.Add(ComboBox_ChooseCountry.SelectedItem, ComboBox_ChooseTeam.SelectedItem, TB_PlayerNumber.Text, TB_PlayerName.Text, ComboBox_PlayerPosition.Text);
                    Listbox_Player.Items.Clear();
                    for (int i = 0; i < Football.Rows.Count; i++)
                    {
                        if (Football.Rows[i][1] == ComboBox_ChooseTeam.SelectedItem)
                        {
                            Listbox_Player.Items.Add($"({Football.Rows[i][2]}) {Football.Rows[i][3]}, {Football.Rows[i][4]}");
                        }
                    }
                }
                TB_PlayerName.Clear();
                TB_PlayerNumber.Clear();
            }
        }
    }
}

