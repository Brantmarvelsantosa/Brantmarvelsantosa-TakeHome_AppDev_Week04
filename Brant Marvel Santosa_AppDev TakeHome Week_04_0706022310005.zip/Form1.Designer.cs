﻿namespace Brant_Marvel_Santosa___AppDev_TakeHome_Week_04___0706022310005
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_SoccerTeamList = new System.Windows.Forms.Label();
            this.label_ChooseCountry = new System.Windows.Forms.Label();
            this.label_ChooseTeam = new System.Windows.Forms.Label();
            this.label_AddingTeam = new System.Windows.Forms.Label();
            this.ComboBox_ChooseCountry = new System.Windows.Forms.ComboBox();
            this.label_TeamName = new System.Windows.Forms.Label();
            this.ComboBox_ChooseTeam = new System.Windows.Forms.ComboBox();
            this.label_TeamCountry = new System.Windows.Forms.Label();
            this.label_TeamCity = new System.Windows.Forms.Label();
            this.ComboBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.label_PlayerPosition = new System.Windows.Forms.Label();
            this.label_PlayerNumber = new System.Windows.Forms.Label();
            this.label_PlayerName = new System.Windows.Forms.Label();
            this.label_AddingPlayers = new System.Windows.Forms.Label();
            this.Listbox_Player = new System.Windows.Forms.ListBox();
            this.button_removelistbox = new System.Windows.Forms.Button();
            this.button_addteam = new System.Windows.Forms.Button();
            this.button_addplayer = new System.Windows.Forms.Button();
            this.TB_TeamCountry = new System.Windows.Forms.TextBox();
            this.TB_TeamName = new System.Windows.Forms.TextBox();
            this.TB_TeamCity = new System.Windows.Forms.TextBox();
            this.TB_PlayerName = new System.Windows.Forms.TextBox();
            this.TB_PlayerNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label_SoccerTeamList
            // 
            this.label_SoccerTeamList.AutoSize = true;
            this.label_SoccerTeamList.Location = new System.Drawing.Point(21, 55);
            this.label_SoccerTeamList.Name = "label_SoccerTeamList";
            this.label_SoccerTeamList.Size = new System.Drawing.Size(132, 20);
            this.label_SoccerTeamList.TabIndex = 0;
            this.label_SoccerTeamList.Text = "Soccer Team List";
            // 
            // label_ChooseCountry
            // 
            this.label_ChooseCountry.AutoSize = true;
            this.label_ChooseCountry.Location = new System.Drawing.Point(21, 104);
            this.label_ChooseCountry.Name = "label_ChooseCountry";
            this.label_ChooseCountry.Size = new System.Drawing.Size(127, 20);
            this.label_ChooseCountry.TabIndex = 1;
            this.label_ChooseCountry.Text = "Choose Country:";
            // 
            // label_ChooseTeam
            // 
            this.label_ChooseTeam.AutoSize = true;
            this.label_ChooseTeam.Location = new System.Drawing.Point(21, 151);
            this.label_ChooseTeam.Name = "label_ChooseTeam";
            this.label_ChooseTeam.Size = new System.Drawing.Size(112, 20);
            this.label_ChooseTeam.TabIndex = 2;
            this.label_ChooseTeam.Text = "Choose Team:";
            // 
            // label_AddingTeam
            // 
            this.label_AddingTeam.AutoSize = true;
            this.label_AddingTeam.Location = new System.Drawing.Point(529, 55);
            this.label_AddingTeam.Name = "label_AddingTeam";
            this.label_AddingTeam.Size = new System.Drawing.Size(103, 20);
            this.label_AddingTeam.TabIndex = 3;
            this.label_AddingTeam.Text = "Adding Team";
            // 
            // ComboBox_ChooseCountry
            // 
            this.ComboBox_ChooseCountry.FormattingEnabled = true;
            this.ComboBox_ChooseCountry.Items.AddRange(new object[] {
            "England",
            "Italy"});
            this.ComboBox_ChooseCountry.Location = new System.Drawing.Point(158, 102);
            this.ComboBox_ChooseCountry.Name = "ComboBox_ChooseCountry";
            this.ComboBox_ChooseCountry.Size = new System.Drawing.Size(188, 28);
            this.ComboBox_ChooseCountry.TabIndex = 4;
            this.ComboBox_ChooseCountry.SelectedIndexChanged += new System.EventHandler(this.ComboBox_ChooseCountry_SelectedIndexChanged);
            // 
            // label_TeamName
            // 
            this.label_TeamName.AutoSize = true;
            this.label_TeamName.Location = new System.Drawing.Point(404, 104);
            this.label_TeamName.Name = "label_TeamName";
            this.label_TeamName.Size = new System.Drawing.Size(99, 20);
            this.label_TeamName.TabIndex = 5;
            this.label_TeamName.Text = "Team Name:";
            // 
            // ComboBox_ChooseTeam
            // 
            this.ComboBox_ChooseTeam.FormattingEnabled = true;
            this.ComboBox_ChooseTeam.Location = new System.Drawing.Point(158, 148);
            this.ComboBox_ChooseTeam.Name = "ComboBox_ChooseTeam";
            this.ComboBox_ChooseTeam.Size = new System.Drawing.Size(188, 28);
            this.ComboBox_ChooseTeam.TabIndex = 6;
            this.ComboBox_ChooseTeam.SelectedIndexChanged += new System.EventHandler(this.ComboBox_ChooseTeam_SelectedIndexChanged);
            // 
            // label_TeamCountry
            // 
            this.label_TeamCountry.AutoSize = true;
            this.label_TeamCountry.Location = new System.Drawing.Point(404, 151);
            this.label_TeamCountry.Name = "label_TeamCountry";
            this.label_TeamCountry.Size = new System.Drawing.Size(112, 20);
            this.label_TeamCountry.TabIndex = 7;
            this.label_TeamCountry.Text = "Team Country:";
            // 
            // label_TeamCity
            // 
            this.label_TeamCity.AutoSize = true;
            this.label_TeamCity.Location = new System.Drawing.Point(404, 196);
            this.label_TeamCity.Name = "label_TeamCity";
            this.label_TeamCity.Size = new System.Drawing.Size(83, 20);
            this.label_TeamCity.TabIndex = 8;
            this.label_TeamCity.Text = "Team City:";
            // 
            // ComboBox_PlayerPosition
            // 
            this.ComboBox_PlayerPosition.FormattingEnabled = true;
            this.ComboBox_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.ComboBox_PlayerPosition.Location = new System.Drawing.Point(904, 197);
            this.ComboBox_PlayerPosition.Name = "ComboBox_PlayerPosition";
            this.ComboBox_PlayerPosition.Size = new System.Drawing.Size(188, 28);
            this.ComboBox_PlayerPosition.TabIndex = 16;
            // 
            // label_PlayerPosition
            // 
            this.label_PlayerPosition.AutoSize = true;
            this.label_PlayerPosition.Location = new System.Drawing.Point(779, 200);
            this.label_PlayerPosition.Name = "label_PlayerPosition";
            this.label_PlayerPosition.Size = new System.Drawing.Size(116, 20);
            this.label_PlayerPosition.TabIndex = 15;
            this.label_PlayerPosition.Text = "Player Position:";
            // 
            // label_PlayerNumber
            // 
            this.label_PlayerNumber.AutoSize = true;
            this.label_PlayerNumber.Location = new System.Drawing.Point(779, 155);
            this.label_PlayerNumber.Name = "label_PlayerNumber";
            this.label_PlayerNumber.Size = new System.Drawing.Size(116, 20);
            this.label_PlayerNumber.TabIndex = 14;
            this.label_PlayerNumber.Text = "Player Number:";
            // 
            // label_PlayerName
            // 
            this.label_PlayerName.AutoSize = true;
            this.label_PlayerName.Location = new System.Drawing.Point(779, 108);
            this.label_PlayerName.Name = "label_PlayerName";
            this.label_PlayerName.Size = new System.Drawing.Size(102, 20);
            this.label_PlayerName.TabIndex = 13;
            this.label_PlayerName.Text = "Player Name:";
            // 
            // label_AddingPlayers
            // 
            this.label_AddingPlayers.AutoSize = true;
            this.label_AddingPlayers.Location = new System.Drawing.Point(904, 59);
            this.label_AddingPlayers.Name = "label_AddingPlayers";
            this.label_AddingPlayers.Size = new System.Drawing.Size(114, 20);
            this.label_AddingPlayers.TabIndex = 12;
            this.label_AddingPlayers.Text = "Adding Players";
            // 
            // Listbox_Player
            // 
            this.Listbox_Player.FormattingEnabled = true;
            this.Listbox_Player.ItemHeight = 20;
            this.Listbox_Player.Location = new System.Drawing.Point(25, 230);
            this.Listbox_Player.Name = "Listbox_Player";
            this.Listbox_Player.Size = new System.Drawing.Size(321, 164);
            this.Listbox_Player.TabIndex = 19;
            // 
            // button_removelistbox
            // 
            this.button_removelistbox.Location = new System.Drawing.Point(25, 400);
            this.button_removelistbox.Name = "button_removelistbox";
            this.button_removelistbox.Size = new System.Drawing.Size(92, 38);
            this.button_removelistbox.TabIndex = 20;
            this.button_removelistbox.Text = "Remove";
            this.button_removelistbox.UseVisualStyleBackColor = true;
            this.button_removelistbox.Click += new System.EventHandler(this.button_removelistbox_Click);
            // 
            // button_addteam
            // 
            this.button_addteam.Location = new System.Drawing.Point(525, 245);
            this.button_addteam.Name = "button_addteam";
            this.button_addteam.Size = new System.Drawing.Size(92, 38);
            this.button_addteam.TabIndex = 21;
            this.button_addteam.Text = "Add";
            this.button_addteam.UseVisualStyleBackColor = true;
            this.button_addteam.Click += new System.EventHandler(this.button_addteam_Click);
            // 
            // button_addplayer
            // 
            this.button_addplayer.Location = new System.Drawing.Point(904, 245);
            this.button_addplayer.Name = "button_addplayer";
            this.button_addplayer.Size = new System.Drawing.Size(92, 38);
            this.button_addplayer.TabIndex = 22;
            this.button_addplayer.Text = "Add";
            this.button_addplayer.UseVisualStyleBackColor = true;
            this.button_addplayer.Click += new System.EventHandler(this.button_addplayer_Click);
            // 
            // TB_TeamCountry
            // 
            this.TB_TeamCountry.Location = new System.Drawing.Point(525, 150);
            this.TB_TeamCountry.Name = "TB_TeamCountry";
            this.TB_TeamCountry.Size = new System.Drawing.Size(188, 26);
            this.TB_TeamCountry.TabIndex = 23;
            // 
            // TB_TeamName
            // 
            this.TB_TeamName.Location = new System.Drawing.Point(525, 102);
            this.TB_TeamName.Name = "TB_TeamName";
            this.TB_TeamName.Size = new System.Drawing.Size(188, 26);
            this.TB_TeamName.TabIndex = 24;
            // 
            // TB_TeamCity
            // 
            this.TB_TeamCity.Location = new System.Drawing.Point(526, 195);
            this.TB_TeamCity.Name = "TB_TeamCity";
            this.TB_TeamCity.Size = new System.Drawing.Size(188, 26);
            this.TB_TeamCity.TabIndex = 25;
            this.TB_TeamCity.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // TB_PlayerName
            // 
            this.TB_PlayerName.Location = new System.Drawing.Point(904, 106);
            this.TB_PlayerName.Name = "TB_PlayerName";
            this.TB_PlayerName.Size = new System.Drawing.Size(188, 26);
            this.TB_PlayerName.TabIndex = 26;
            // 
            // TB_PlayerNumber
            // 
            this.TB_PlayerNumber.Location = new System.Drawing.Point(904, 153);
            this.TB_PlayerNumber.Name = "TB_PlayerNumber";
            this.TB_PlayerNumber.Size = new System.Drawing.Size(188, 26);
            this.TB_PlayerNumber.TabIndex = 27;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 450);
            this.Controls.Add(this.TB_PlayerNumber);
            this.Controls.Add(this.TB_PlayerName);
            this.Controls.Add(this.TB_TeamCity);
            this.Controls.Add(this.TB_TeamName);
            this.Controls.Add(this.TB_TeamCountry);
            this.Controls.Add(this.button_addplayer);
            this.Controls.Add(this.button_addteam);
            this.Controls.Add(this.button_removelistbox);
            this.Controls.Add(this.Listbox_Player);
            this.Controls.Add(this.ComboBox_PlayerPosition);
            this.Controls.Add(this.label_PlayerPosition);
            this.Controls.Add(this.label_PlayerNumber);
            this.Controls.Add(this.label_PlayerName);
            this.Controls.Add(this.label_AddingPlayers);
            this.Controls.Add(this.label_TeamCity);
            this.Controls.Add(this.label_TeamCountry);
            this.Controls.Add(this.ComboBox_ChooseTeam);
            this.Controls.Add(this.label_TeamName);
            this.Controls.Add(this.ComboBox_ChooseCountry);
            this.Controls.Add(this.label_AddingTeam);
            this.Controls.Add(this.label_ChooseTeam);
            this.Controls.Add(this.label_ChooseCountry);
            this.Controls.Add(this.label_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_SoccerTeamList;
        private System.Windows.Forms.Label label_ChooseCountry;
        private System.Windows.Forms.Label label_ChooseTeam;
        private System.Windows.Forms.Label label_AddingTeam;
        private System.Windows.Forms.ComboBox ComboBox_ChooseCountry;
        private System.Windows.Forms.Label label_TeamName;
        private System.Windows.Forms.ComboBox ComboBox_ChooseTeam;
        private System.Windows.Forms.Label label_TeamCountry;
        private System.Windows.Forms.Label label_TeamCity;
        private System.Windows.Forms.ComboBox ComboBox_PlayerPosition;
        private System.Windows.Forms.Label label_PlayerPosition;
        private System.Windows.Forms.Label label_PlayerNumber;
        private System.Windows.Forms.Label label_PlayerName;
        private System.Windows.Forms.Label label_AddingPlayers;
        private System.Windows.Forms.ListBox Listbox_Player;
        private System.Windows.Forms.Button button_removelistbox;
        private System.Windows.Forms.Button button_addteam;
        private System.Windows.Forms.Button button_addplayer;
        private System.Windows.Forms.TextBox TB_TeamCountry;
        private System.Windows.Forms.TextBox TB_TeamName;
        private System.Windows.Forms.TextBox TB_TeamCity;
        private System.Windows.Forms.TextBox TB_PlayerName;
        private System.Windows.Forms.TextBox TB_PlayerNumber;
    }
}

